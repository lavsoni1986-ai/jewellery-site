// lib/config.ts
export const GSTIN = "23DKHPS2997L1ZD";
export const PHONE = "9425182098";
export const SHOP_NAME = "Anshu Jewellers";